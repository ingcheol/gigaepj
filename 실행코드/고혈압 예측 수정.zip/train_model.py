import pandas as pd
from xgboost import XGBClassifier
import joblib

# ✅ 1. 데이터 불러오기
df = pd.read_csv("processed_balanced.csv")

# ✅ 2. 전처리
df = df.drop(columns=["ID"])
df["DI1_pr"] = df["DI1_pr"].astype(int)

# ✅ 3. 독립변수 / 종속변수 분리
X = df[["sex", "age", "BS3_2", "BS12_47", "HE_BMI"]]
y = df["DI1_pr"]

# ✅ 4. XGBoost 모델 학습
model = XGBClassifier(use_label_encoder=False, eval_metric='logloss', scale_pos_weight=1, random_state=42)
model.fit(X, y)

# ✅ 5. 모델 저장
joblib.dump(model, "xgb_hypertension_predictor.pkl")
print("✅ 모델 저장 완료: xgb_hypertension_predictor.pkl")

import streamlit as st
import pandas as pd
import joblib

# 모델 불러오기
model = joblib.load('xgb_hypertension_predictor.pkl')

st.set_page_config(page_title="고혈압 위험도 예측기", page_icon="🩺")
st.title("🧬 고혈압 위험도 예측기")
st.markdown("건강 정보를 입력하면 **고혈압 위험도(%)** 를 예측합니다.")

# 사용자 입력 받기
sex = st.radio("성별", ["남자", "여자"])
age = st.slider("나이", 20, 80, 40)
bs3_2 = st.slider("하루 평균 궐련 흡연량 (개비)", 0, 60, 10)
bmi = st.slider("체질량지수(BMI)", 10.0, 50.0, 25.0)

# 값 변환
sex_val = 0 if sex == "남자" else 1

# 예측용 입력 데이터프레임 구성
user_input = pd.DataFrame([{
    "sex": sex_val,
    "age": age,
    "BS3_2": bs3_2,
    "HE_BMI": bmi
}])

# 예측 버튼
if st.button("🔍 예측하기"):

    # 1. 29세 이하는 예측하지 않음
    if age <= 29:
        st.info("📘 현재 연령대에서는 고혈압 발생 확률이 낮습니다. 건강관리는 미리미리 하는 게 좋습니다.")
    else:
        # 고혈압 예측
        proba = model.predict_proba(user_input)[0][1]
        risk_percent = proba * 100
        st.markdown(f"### 🧿 예측된 고혈압 위험도: **{risk_percent:.2f}%**")

        # 시각적 위험도 표시
        st.progress(min(int(risk_percent), 100))

        # 위험 등급 메시지
        if risk_percent >= 70:
            st.error("🚨 [고위험] 전문가 상담이 필요할 수 있습니다.")
        elif risk_percent >= 40:
            st.warning("⚠️ [중위험] 생활습관 개선과 정기 검진이 필요합니다.")
        else:
            st.success("🟢 [저위험] 현재는 위험도가 낮습니다.")

    # 2. 흡연량이 20개비 초과일 경우 경고
    if bs3_2 > 20:
        st.warning("🚬 하루 20개비 이상의 흡연은 고혈압의 주요 원인입니다. 전문가 상담을 권장합니다.")

    # 입력 요약
    st.markdown("---")
    st.markdown("#### 🧾 입력 정보 요약")
    st.markdown(f"- 성별: {sex}")
    st.markdown(f"- 나이: {age}세")
    st.markdown(f"- 궐련 흡연량: {bs3_2}개비")
    st.markdown(f"- BMI: {bmi}")
